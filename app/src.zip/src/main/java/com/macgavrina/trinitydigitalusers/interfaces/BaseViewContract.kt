package com.macgavrina.trinitydigitalusers.interfaces

public interface BaseViewContract {
}